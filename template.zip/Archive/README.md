# Word Guess Game (Browser)

<!-- TODO: add one sentence overview here of your progress -->

## Overview

<!-- TODO: add a description of your assignment, theme, approach, and solution here -->

## Functionality Breakdown
<!-- TODO: update this to your screenshot, gif, etc. demonstrating functionality. add any additional explanation below -->
[Screenshot of Game](images/screenshot1.png)

